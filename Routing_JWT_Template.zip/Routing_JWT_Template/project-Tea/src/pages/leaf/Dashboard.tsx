import React from "react";
import Grid from "@mui/material/Grid";
import { Paper, Typography, Stack,Box } from "@mui/material";

// Line Chart
import { LineChart } from "@mui/x-charts/LineChart";
import { PieChart, pieArcLabelClasses } from '@mui/x-charts/PieChart';
import { BarChart } from '@mui/x-charts/BarChart';

import { styled } from '@mui/material/styles';
import { useDrawingArea } from '@mui/x-charts/hooks';
import { blueberryTwilightPalette } from "@mui/x-charts/colorPalettes";

// Button1
import { GiFarmer } from "react-icons/gi";

// Button2
import { FaLeaf } from "react-icons/fa6";

// Button3
import { GiNotebook } from "react-icons/gi";

// Button4
import { FaScaleBalanced } from "react-icons/fa6";

function Dashboard() {
  const xLables = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];

  const factoryData = [300, 1000, 800, 0, 500, 700, 400, 850, 650, 900, 800, 450];
  const wagaData = [100, 600, 500, 650, 200, 50, 150, 500, 900, 750, 300, 550];

  const piChartData = [
    {label: 'Factory', value: 800, color: '#4F900E'},
    {label: 'Route A', value: 300, color: '#9D5D09'},
    {label: 'Route B', value: 400, color: '#1B8C9A'},
    {label: 'Route C', value: 500, color: '#5B48A8'},
    {label: 'Route D', value: 700, color: '#1E1E1E'},
    {label: 'Route E', value: 300, color: '#A84848'}
  ]

  const TOTAL = piChartData.map((item) => item.value).reduce((a, b) => a + b, 0);

  const getArcLabel = (params) => {
    const percent = params.value / TOTAL;
    return `${(percent * 100).toFixed(0)}% `;
  };

  const barXAxis=['']
const barDataSet=[
  {
    Normal: 1600,
    Super:700
  }
]

const StyledText = styled('text')(({ theme }) => ({
  fill: theme.palette.text.primary,
  textAnchor: 'middle',
  dominantBaseline: 'central',
  fontSize: 20,
}));

function PieCenterLabel({ children }: { children: React.ReactNode }) {
  const { width, height, left, top } = useDrawingArea();
  return (
    <StyledText x={left + width / 2} y={top + height / 2} sx={{
      fontSize:35,
      fontWeight:550
    }}>
      {children}
    </StyledText>
  );
}


const donutData = [
  { value: 7, label: 'Collected' },
  { value: 3 },
]

const donutTotal = ((donutData[0].value/(donutData[0].value + donutData[1].value))*100);

console.log(donutTotal)

  return (
    <React.Fragment>
      <Grid container spacing={4}>
        <Grid item md={9} sm={12} xs={12}>
          <Paper
            sx={{ padding: "10px", height: "46vh", borderRadius: "12px", paddingBottom:2 }}
            elevation={5}
          >
            <Typography
              variant="h5"
              color="initial"
              gutterBottom
              align="left"
              sx={{
                pl: 6,
                pt: 1,
                fontWeight: 550,
              }}
            >
              Monthly Leaf Collection
            </Typography>
            
            <Stack>
              <LineChart
                height={300}
                xAxis={[
                  {
                    scaleType: "point",
                    data: xLables,
                    tickLabelStyle: {
                      // angle:45,
                      textAnchor: "start",
                      fontSize: 15,
                    },
                  },
                ]}
                series={[
                  { data: factoryData, label: "Factory", curve:'linear' },
                  { data: wagaData, label: "Waga", curve:'linear' },
                ]}
               colors={['#4F900E', '#9D5D09']}
               axisHighlight={{x:'line', y:'line'}}
              ></LineChart>
            </Stack>
            
          </Paper>
        </Grid>
        <Grid item md={3} sm={12} xs={12}>
          <Grid container spacing={4}>
            <Grid item sm={12} md={12} xs={12}>
              <Paper
                sx={{ padding: "10px", height: "8vh", borderRadius: "12px" }}
                elevation={5}
              >
                <Stack direction='row' sx={{
                 
                }} spacing={4} px={2}>
                  <GiFarmer style={{color:'black'}} size='2.5em'/>
                  <Typography variant="h5" sx={{
                    fontWeight:550
                  }}>
                    Supplier
                  </Typography>
                </Stack>
              </Paper>
            </Grid>
            <Grid item sm={12} md={12} xs={12}>
              <Paper
                sx={{ padding: "10px", height: "8vh", borderRadius: "12px" }}
                elevation={5}
              >
                <Stack direction='row' sx={{
                 
                }} spacing={4} px={2}>
                  <FaLeaf style={{color:'black'}} size='2em'/>
                  <Typography variant="h5" sx={{
                    fontWeight:550
                  }}>
                    Leaf Entry
                  </Typography>
                </Stack>
              </Paper>
            </Grid>
            <Grid item sm={12} md={12} xs={12}>
              <Paper
                sx={{ padding: "10px", height: "8vh", borderRadius: "12px" }}
                elevation={5}
              >
                 <Stack direction='row' sx={{
                 
                }} spacing={4} px={2}>
                  <GiNotebook style={{color:'black'}} size='2em'/>
                  <Typography variant="h5" sx={{
                    fontWeight:550
                  }}>
                    Leaf Records
                  </Typography>
                </Stack>
              </Paper>
            </Grid>
            <Grid item sm={12} md={12} xs={12}>
              <Paper
                sx={{ padding: "10px", height: "8vh", borderRadius: "12px" }}
                elevation={5}
              >
                 <Stack direction='row' sx={{
                 
                }} spacing={4} px={2}>
                  <FaScaleBalanced style={{color:'black'}} size='2em'/>
                  <Typography variant="h5" sx={{
                    fontWeight:550
                  }}>
                    Actual Weight
                  </Typography>
                </Stack>
              </Paper>
            </Grid>
          </Grid>
        </Grid>
        <Grid item md={4} sm={12} xs={12}>
          <Paper
            sx={{ padding: "10px", height: "40vh", borderRadius: "12px" }}
            elevation={5}
          >
            <Typography variant="h5" pl={6} gutterBottom sx={{
              fontWeight:550
            }}>Monthly Target</Typography>

<Stack>
  <PieChart series={[{ data:donutData, innerRadius: 80 }]} height={200} colors={[
    '#4F900E',
    '#F5F5F5'
  ]}>
        <PieCenterLabel>
         {donutTotal}%
          </PieCenterLabel>
      </PieChart>
</Stack>
          </Paper>
        </Grid>
        <Grid item md={4} sm={12} xs={12} sx={{ height: 2 / 5 }}>
          <Paper
            sx={{ padding: "10px", height: "40vh", borderRadius: "12px" }}
            elevation={5}
          >
            <Typography variant="h5" pl={6} gutterBottom sx={{
              fontWeight:550
            }}>Daily Leaf Collection</Typography>
            <Stack>
              <BarChart
              height={280}
              xAxis={[
                {
                  data:barXAxis,
                  scaleType:'band'
                }
              ]}
               dataset={barDataSet}
               series={[
                {dataKey:'Normal', label:'Normal'},
                {dataKey:'Super', label:'Super'}
               ]}
               colors={[
                '#4F900E',
                '#9D5D09'
               ]}
              >
              </BarChart>
            </Stack>
          </Paper>
        </Grid>
        <Grid item md={4} sm={12} xs={12} sx={{ height: 2 / 5 }}>
          <Paper
            sx={{ padding: "10px", height: "40vh", borderRadius: "12px" }}
            elevation={5}
          >
           <Typography variant="h5" pl={6} gutterBottom sx={{
            fontWeight:550
           }}>
           Monthly Route Collection
           </Typography>
          
           <Stack>
             <PieChart
             height={240}
               series={[
                {
                  data:piChartData,
                  arcLabel:getArcLabel
                }
               ]}
               sx={{
                [`& .${pieArcLabelClasses.root}`]: {
                  fill: 'white',
                  fontSize: 16,
                },
              }}>
               </PieChart>
           </Stack>
           
          </Paper>
        </Grid>
      </Grid>
    </React.Fragment>
  );
}

export default Dashboard;
