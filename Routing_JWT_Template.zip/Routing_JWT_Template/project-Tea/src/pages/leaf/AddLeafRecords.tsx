import React from 'react'

function AddLeafRecords() {
  return (
    <div>Add Leaf Records</div>
  )
}

export default AddLeafRecords