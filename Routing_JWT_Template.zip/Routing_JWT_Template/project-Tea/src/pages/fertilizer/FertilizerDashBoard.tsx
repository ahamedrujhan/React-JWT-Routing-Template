import React from 'react'

function FertilizerDashBoard() {
  return (
    <div>Fertilizer DashBoard</div>
  )
}

export default FertilizerDashBoard