import React from 'react'
import { useAuth } from '../../provider/AuthProvider'
import { useNavigate } from 'react-router-dom';



function Logout() {

    const {setAccessTokenfunc,setRefreshTokenfunc} = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        setAccessTokenfunc();
        setRefreshTokenfunc();
        navigate('/', { replace: true})

    }

    setTimeout(() => {
        handleLogout();
    });

  return (
    <></>
  )
}

export default Logout