import { Typography } from '@mui/material'
import React from 'react'
import { FaSadCry } from "react-icons/fa";

function PageNotFound() {
  return (
    <div>
        <Typography variant='h4' gutterBottom>
            Page Not Found  <FaSadCry />
        </Typography>
        <Typography variant='h5'>
            404
        </Typography>
        <br></br>
        <br></br>
        <Typography variant='body1'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum eius quidem maxime dolore, excepturi voluptates error voluptatem sapiente expedita repudiandae quae, illo asperiores porro possimus atque ex? Odit, possimus voluptatem.</Typography>
    </div>
  )
}

export default PageNotFound