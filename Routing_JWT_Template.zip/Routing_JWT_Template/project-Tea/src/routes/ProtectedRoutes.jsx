import React from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import RootLayout from '../layouts/RootLayout'
import { useAuth } from '../provider/AuthProvider'
function ProtectedRoutes() {

    const jwt = useAuth().accessToken;

    if (!jwt) {
        return <Navigate to='/login' />
    }

    return <RootLayout/>
}

export default ProtectedRoutes