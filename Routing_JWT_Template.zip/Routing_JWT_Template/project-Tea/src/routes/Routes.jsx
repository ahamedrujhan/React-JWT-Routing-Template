import React from 'react'
import ProtectedRoutes from './ProtectedRoutes';
import Dashboard from '../pages/leaf/Dashboard';
import AddLeafRecords from '../pages/leaf/AddLeafRecords';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import FertilizerDashBoard from '../pages/fertilizer/FertilizerDashBoard';
import PageNotFound from '../pages/notFound/PageNotFound';
import Login from '../pages/Login/Login';
import { useAuth } from '../provider/AuthProvider';
import Logout from '../pages/logout/Logout';
function Routes() {



    const jwt = useAuth().accessToken;

    const routesForPublic = [
        {
            path: '/test1',
            element : <div>Test1</div>
        },
        {
            path: '/test2',
            element : <div>Test2</div>
        },
        {
            path: '*',
            element: <PageNotFound/>
        }
    ]

    const routesForAuth = [
        {
            path: '/',
            element: <ProtectedRoutes/>,
            children: [
               { 
                path: '',
                element: <Dashboard/>
            },
            {
                path: 'add_leaf',
                element: <AddLeafRecords/>
            },
            //fertilizer
            {
                path:'fertilizer',
                element: <FertilizerDashBoard/>
            },
            //firewood
            {
                path: 'firewood',
                element: <div>Firewood</div>
                
            },
            //Logout
            {
                path: 'logout',
                element: <Logout/>
            }
            ]
        }
    ]

    const routesForNotAuth = [
        {
            path: '',
            element: <Login />
        }
    ]


    // Conditionaly Routing...

    const router = createBrowserRouter([
        ...routesForPublic,
        ...(!jwt ?routesForNotAuth: []),
        ...routesForAuth,

    ])


  return (
    <RouterProvider router={router}/>
  )
}

export default Routes