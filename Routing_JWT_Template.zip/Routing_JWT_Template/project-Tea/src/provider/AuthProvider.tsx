import axios from 'axios';
import React, { createContext,  useContext,  useEffect, useMemo, useState } from 'react'

const AuthContext = createContext();

function AuthProvider({children}) {

    //Hold the Access Token
    const [accessToken, setAccessToken] = useState(sessionStorage.getItem("accessToken"));
    const [refreshToken, setRefreshToken] = useState(sessionStorage.getItem("refreshToken"));

    //Function to setAccessToken
    const setAccessTokenfunc = (token) => {
        setAccessToken(token);
    }
    //Function to setRefreshtoken
    const setRefreshTokenfunc = (token) => {
        setRefreshToken(token);
    }

    useEffect(() => {
        if(accessToken) {
            axios.defaults.headers.common['Authorization'] = "Bearer " + accessToken;
            sessionStorage.setItem("accessToken", accessToken);
            sessionStorage.setItem("refreshToken", refreshToken);
        } else {
            delete axios.defaults.headers.common['Authorization'];
            sessionStorage.removeItem("accessToken")
            sessionStorage.removeItem("refreshToken")
        }
    },[accessToken]);

    //Memorize the AuthContext values
    const contextValue = useMemo(
        () => ({
            accessToken,
            setAccessTokenfunc,
            refreshToken,
            setRefreshTokenfunc
        }),[accessToken]
    );

    // Provide the authentication context to the children components
  return (
    <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>
  )
}

export const useAuth = () => {
    return useContext(AuthContext)
};

export default AuthProvider