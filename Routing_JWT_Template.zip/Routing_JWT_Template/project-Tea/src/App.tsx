import { useState } from 'react'
import './App.css'
import AppBarTop from './components/root/AppBarTop'
import RootLayout from './layouts/RootLayout'
import { Route, RouterProvider, createBrowserRouter, createRoutesFromElements } from 'react-router-dom'

//leaf part
import Dashboard from './pages/leaf/Dashboard'
import AddLeafRecords from './pages/leaf/AddLeafRecords'
import PageNotFound from './pages/notFound/PageNotFound'
import Test from './pages/leaf/Test'
import Routes from './routes/Routes'
import AuthProvider from './provider/AuthProvider'
import React from 'react'







function App() {

  return (
    // <AppBarTop/>
  //  <SideDrawer/>
  // <RouterProvider router={router}/>
  <AuthProvider>
 <Routes/>
  </AuthProvider>
 
  )
}

export default App
